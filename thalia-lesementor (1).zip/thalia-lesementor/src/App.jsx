import { useState, useEffect, useRef } from "react";

// ─── Thalia Real CI (aus Screenshot) ──────────────────────────────────────
const T_GREEN       = "#1e7a3c";   // Logo-Grün
const T_GREEN_DARK  = "#155a2c";   // Hover
const T_GREEN_LIGHT = "#e8f5ed";   // Hintergrund-Grün
const T_HERO_BG     = "#0d3349";   // Hero dunkles Blaugrün
const T_ORANGE      = "#e84e0e";   // SALE / CTA Badge
const T_WHITE       = "#ffffff";
const T_BG          = "#f5f7fa";
const T_TEXT        = "#1a1a1a";
const T_TEXT_MUTED  = "#6b7280";
const T_BORDER      = "#e0e0e0";
const T_BLUE_LIGHT  = "#e8eef7";
const T_BLUE        = "#003882";   // für Chat-Bubbles / Agenten-UI

const books = [
  {
    id: 1,
    title: "Intermezzo",
    author: "Sally Rooney",
    cover: ["#1a3a5c", "#2e6da4"],
    genre: "Literarische Fiktion",
    pages: 448,
    price: "24,00 €",
    rating: 4.6,
    reviews: 1842,
    reason: "Basierend auf deiner Liebe zu Rooney's Prosa — ihr jüngster Roman erkundet Geschwisterdynamiken mit der gleichen emotionalen Präzision wie Normal People.",
    tags: ["Zeitgenössisch", "Emotional", "Longlisted"],
    matchScore: 97,
    badge: "NEU",
  },
  {
    id: 2,
    title: "Das Café am Rande der Welt",
    author: "John Strelecky",
    cover: ["#1a4a2e", "#2e7a4a"],
    genre: "Philosophischer Roman",
    pages: 176,
    price: "12,00 €",
    rating: 4.8,
    reviews: 32104,
    reason: "Du hast Bücher über Sinn und Lebensphilosophie hoch bewertet. Dieser Bestseller stellt die drei großen Fragen in einer zugänglichen, berührenden Geschichte.",
    tags: ["Bestseller", "Philosophie", "Kurzroman"],
    matchScore: 94,
    badge: "BESTSELLER",
  },
  {
    id: 3,
    title: "Orbital",
    author: "Samantha Harvey",
    cover: ["#1a1a3c", "#3a3a7a"],
    genre: "Literarische Fiktion",
    pages: 208,
    price: "22,00 €",
    rating: 4.4,
    reviews: 3201,
    reason: "Dein Interesse an lyrischer Prosa und existenziellen Themen trifft hier auf einen Booker-Preisträger über einen einzigen Umlauf der ISS.",
    tags: ["Booker Prize", "Lyrisch", "Weltraum"],
    matchScore: 91,
    badge: "PREISGEKRÖNT",
  },
  {
    id: 4,
    title: "James",
    author: "Percival Everett",
    cover: ["#3c1a1a", "#7a3a2a"],
    genre: "Historischer Roman",
    pages: 320,
    price: "26,00 €",
    rating: 4.7,
    reviews: 5620,
    reason: "Eine Neuerzählung von Huckleberry Finn aus Jim's Perspektive — revolutionäres Erzählen für deine Vorliebe für frische historische Blickwinkel.",
    tags: ["Pulitzer", "Historisch", "Perspektive"],
    matchScore: 89,
    badge: "PULITZER",
  },
];

const thinkingSteps = [
  "Leseprofil wird analysiert …",
  "Bewertete Bücher werden ausgewertet …",
  "Genrepräferenzen werden erkannt …",
  "Ähnliche Leser:innen werden verglichen …",
  "Top-Empfehlungen werden zusammengestellt …",
];

const navItems = ["Ostern","Bücher","Englische Bücher","Gebrauchte Bücher","eBooks","tolino","Hörbücher","Spielzeug","Schreibwaren","Geschenke","SALE","Club","Gutschein"];

// ─── Thalia Logo SVG (Vogel + Wortmarke) ──────────────────────────────────
function ThaliaLogo() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
      {/* Bird icon - stylized from Thalia brand */}
      <svg width="38" height="38" viewBox="0 0 38 38" fill="none">
        <path d="M19 4 C14 4 8 8 7 14 C6 18 8 21 11 23 C9 25 8 28 9 31 C11 28 14 26 17 25 C18 26 19 27 19 29 C19 27 20 25 22 24 C25 25 27 28 29 31 C30 28 29 25 27 23 C30 21 32 18 31 14 C30 8 24 4 19 4Z" fill={T_GREEN}/>
        <path d="M19 7 C16 7 12 9 11 13 C10.5 16 12 18.5 14.5 20 C13 21 12 23 12.5 25 C14 23 16 22 18 21.5 C18.5 22.5 19 23.5 19 25 C19 23.5 19.5 22.5 20 21.5 C22 22 24 23 25.5 25 C26 23 25 21 23.5 20 C26 18.5 27.5 16 27 13 C26 9 22 7 19 7Z" fill={T_GREEN_DARK} opacity="0.3"/>
        <circle cx="15.5" cy="13" r="1.5" fill={T_WHITE}/>
      </svg>
      {/* Wordmark */}
      <span style={{
        fontSize: "26px", fontWeight: 800, color: T_TEXT,
        fontFamily: "'Source Sans 3', Helvetica, Arial, sans-serif",
        letterSpacing: "-0.5px", lineHeight: 1,
      }}>Thalia</span>
    </div>
  );
}

// ─── Sub-components ────────────────────────────────────────────────────────

function BookCover({ colors, size = "md" }) {
  const dims = { sm: { w: 44, h: 62 }, md: { w: 72, h: 100 }, lg: { w: 96, h: 136 } };
  const d = dims[size];
  return (
    <div style={{
      width: d.w, height: d.h, borderRadius: "3px",
      background: `linear-gradient(160deg, ${colors[0]} 0%, ${colors[1]} 100%)`,
      flexShrink: 0, position: "relative", overflow: "hidden",
      boxShadow: "2px 3px 10px rgba(0,0,0,0.28), inset -3px 0 6px rgba(0,0,0,0.18)",
    }}>
      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "5px", background: "rgba(0,0,0,0.22)" }} />
      <div style={{ position: "absolute", left: "8px", top: "7px", right: "5px", bottom: "7px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "1px" }} />
    </div>
  );
}

function StarRating({ rating }) {
  return (
    <div style={{ display: "flex", gap: "2px", alignItems: "center" }}>
      {[1,2,3,4,5].map(s => (
        <svg key={s} width="13" height="13" viewBox="0 0 13 13">
          <polygon
            points="6.5,1 8.2,4.8 12.5,5.2 9.5,7.9 10.4,12 6.5,9.8 2.6,12 3.5,7.9 0.5,5.2 4.8,4.8"
            fill={s <= Math.round(rating) ? T_ORANGE : "#ddd"}
          />
        </svg>
      ))}
      <span style={{ fontSize: "12px", color: T_TEXT_MUTED, marginLeft: "4px", fontWeight: 600 }}>{rating.toFixed(1)}</span>
    </div>
  );
}

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: "4px", padding: "10px 0 4px", alignItems: "center" }}>
      {[0,1,2].map(i => (
        <div key={i} style={{
          width: "7px", height: "7px", borderRadius: "50%", background: T_GREEN,
          opacity: 0.6, animation: `tDot 1.2s ease-in-out ${i*0.22}s infinite`,
        }} />
      ))}
    </div>
  );
}

function AgentThinking({ currentStep }) {
  return (
    <div style={{
      background: T_GREEN_LIGHT, borderRadius: "10px", padding: "14px 16px",
      border: `1px solid #b6dfc4`, marginBottom: "6px",
    }}>
      <div style={{ fontSize: "11px", fontWeight: 700, color: T_GREEN, marginBottom: "10px", letterSpacing: "0.08em", textTransform: "uppercase" }}>
        ◆ Lesementor analysiert
      </div>
      {thinkingSteps.map((step, i) => (
        <div key={i} style={{ display: "flex", alignItems: "center", gap: "9px", padding: "4px 0", opacity: i <= currentStep ? 1 : 0.3, transition: "opacity 0.4s" }}>
          <div style={{
            width: "18px", height: "18px", borderRadius: "50%", flexShrink: 0,
            background: i < currentStep ? T_GREEN : i === currentStep ? "transparent" : "#b6dfc4",
            border: i === currentStep ? `2px solid ${T_GREEN}` : "none",
            display: "flex", alignItems: "center", justifyContent: "center",
            animation: i === currentStep ? "tSpin 1s linear infinite" : "none",
          }}>
            {i < currentStep && <span style={{ fontSize: "9px", color: "white", lineHeight: 1 }}>✓</span>}
          </div>
          <span style={{ fontSize: "13px", color: i <= currentStep ? T_TEXT : T_TEXT_MUTED }}>{step}</span>
        </div>
      ))}
    </div>
  );
}

function ChatBubble({ msg, isUser }) {
  return (
    <div style={{ display: "flex", justifyContent: isUser ? "flex-end" : "flex-start", marginBottom: "10px", animation: "tFade 0.35s ease" }}>
      {!isUser && (
        <div style={{
          width: "32px", height: "32px", borderRadius: "50%", background: T_GREEN,
          flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "14px", marginRight: "8px", marginTop: "2px",
        }}>📚</div>
      )}
      <div style={{
        maxWidth: "82%",
        background: isUser ? T_GREEN : T_WHITE,
        color: isUser ? T_WHITE : T_TEXT,
        padding: "11px 15px", fontSize: "13.5px", lineHeight: 1.6,
        borderRadius: isUser ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
        border: isUser ? "none" : `1px solid ${T_BORDER}`,
        boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
      }}>
        {msg}
      </div>
    </div>
  );
}

function BadgePill({ label }) {
  const colors = {
    NEU: { bg: T_ORANGE, color: "white" },
    BESTSELLER: { bg: T_GREEN, color: "white" },
    PREISGEKRÖNT: { bg: "#6b21a8", color: "white" },
    PULITZER: { bg: "#166534", color: "white" },
  };
  const c = colors[label] || { bg: "#eee", color: T_TEXT };
  return (
    <span style={{
      background: c.bg, color: c.color,
      fontSize: "9px", fontWeight: 800, letterSpacing: "0.07em",
      padding: "2px 7px", borderRadius: "3px",
    }}>{label}</span>
  );
}

function BookCard({ book, onAdd, visible }) {
  const [added, setAdded] = useState(false);
  const handleAdd = () => { setAdded(true); onAdd(book); setTimeout(() => setAdded(false), 2500); };
  return (
    <div style={{
      background: T_WHITE, borderRadius: "8px", border: `1px solid ${T_BORDER}`,
      padding: "20px", marginBottom: "12px",
      opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(14px)",
      transition: "all 0.45s ease", boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
    }}>
      <div style={{ display: "flex", gap: "16px", marginBottom: "14px" }}>
        <BookCover colors={book.cover} size="lg" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px", marginBottom: "5px" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "7px", marginBottom: "3px" }}>
                <BadgePill label={book.badge} />
                <span style={{ fontSize: "11px", color: T_TEXT_MUTED }}>{book.genre}</span>
              </div>
              <div style={{ fontSize: "17px", fontWeight: 700, color: T_TEXT, lineHeight: 1.25, marginBottom: "2px" }}>{book.title}</div>
              <div style={{ fontSize: "13px", color: T_TEXT_MUTED }}>{book.author}</div>
            </div>
            <div style={{
              background: T_GREEN_LIGHT, border: `1.5px solid ${T_GREEN}`,
              borderRadius: "6px", padding: "5px 10px", textAlign: "center", flexShrink: 0,
            }}>
              <div style={{ fontSize: "16px", fontWeight: 800, color: T_GREEN, lineHeight: 1 }}>{book.matchScore}%</div>
              <div style={{ fontSize: "9px", color: T_GREEN, fontWeight: 600, letterSpacing: "0.06em" }}>MATCH</div>
            </div>
          </div>
          <StarRating rating={book.rating} />
          <div style={{ fontSize: "11px", color: T_TEXT_MUTED, marginTop: "2px" }}>
            {book.reviews.toLocaleString("de-DE")} Bewertungen · {book.pages} Seiten
          </div>
          <div style={{ display: "flex", gap: "5px", flexWrap: "wrap", marginTop: "8px" }}>
            {book.tags.map(t => (
              <span key={t} style={{
                background: T_GREEN_LIGHT, color: T_GREEN,
                fontSize: "10px", fontWeight: 700, padding: "2px 9px",
                borderRadius: "12px",
              }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
      <div style={{
        background: "#fff8f5", borderLeft: `3px solid ${T_ORANGE}`,
        borderRadius: "0 6px 6px 0", padding: "11px 14px", marginBottom: "16px",
      }}>
        <div style={{ fontSize: "10px", fontWeight: 800, color: T_ORANGE, marginBottom: "3px", letterSpacing: "0.08em", textTransform: "uppercase" }}>
          Warum dieses Buch für dich?
        </div>
        <div style={{ fontSize: "13px", color: "#5c3310", lineHeight: 1.55 }}>{book.reason}</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: "22px", fontWeight: 800, color: T_TEXT }}>{book.price}</div>
          <div style={{ fontSize: "10px", color: T_TEXT_MUTED }}>inkl. MwSt. · versandkostenfrei ab 9 €</div>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button style={{
            background: T_WHITE, border: `1.5px solid ${T_GREEN}`, color: T_GREEN,
            fontSize: "13px", fontWeight: 700, padding: "10px 16px", borderRadius: "22px",
            cursor: "pointer",
          }}>Mehr Details</button>
          <button onClick={handleAdd} style={{
            background: added ? "#15803d" : T_GREEN,
            color: "white", fontSize: "13px", fontWeight: 700,
            padding: "10px 20px", borderRadius: "22px", border: "none",
            cursor: "pointer", transition: "background 0.3s", minWidth: "160px",
          }}>
            {added ? "✓ Im Warenkorb" : "In den Warenkorb"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ReadingProfile() {
  const genres = [
    { label: "Literarische Fiktion", pct: 88 },
    { label: "Philosophie", pct: 72 },
    { label: "Historische Romane", pct: 61 },
    { label: "Sachbücher", pct: 45 },
  ];
  const recent = [
    { title: "Normal People", author: "S. Rooney", cover: ["#5c1a3a", "#a03060"] },
    { title: "Siddhartha", author: "H. Hesse", cover: ["#1a4a2e", "#2e7a4a"] },
    { title: "Der Prozess", author: "F. Kafka", cover: ["#1a1a3c", "#3a3a6a"] },
  ];
  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: "15px", color: T_TEXT, marginBottom: "16px", borderBottom: `2px solid ${T_GREEN}`, paddingBottom: "10px" }}>
        Mein Leseprofil
      </div>
      <div style={{ marginBottom: "18px" }}>
        <div style={{ fontSize: "11px", fontWeight: 700, color: T_TEXT_MUTED, marginBottom: "10px", letterSpacing: "0.07em", textTransform: "uppercase" }}>Lieblingsgenres</div>
        {genres.map(g => (
          <div key={g.label} style={{ marginBottom: "9px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "3px" }}>
              <span style={{ fontSize: "12px", color: T_TEXT }}>{g.label}</span>
              <span style={{ fontSize: "12px", color: T_GREEN, fontWeight: 700 }}>{g.pct}%</span>
            </div>
            <div style={{ height: "5px", background: "#eee", borderRadius: "3px" }}>
              <div style={{ height: "100%", width: `${g.pct}%`, background: T_GREEN, borderRadius: "3px" }} />
            </div>
          </div>
        ))}
      </div>
      <div>
        <div style={{ fontSize: "11px", fontWeight: 700, color: T_TEXT_MUTED, marginBottom: "10px", letterSpacing: "0.07em", textTransform: "uppercase" }}>Zuletzt gelesen</div>
        {recent.map(b => (
          <div key={b.title} style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "10px" }}>
            <BookCover colors={b.cover} size="sm" />
            <div>
              <div style={{ fontWeight: 700, fontSize: "12px", color: T_TEXT }}>{b.title}</div>
              <div style={{ fontSize: "11px", color: T_TEXT_MUTED }}>{b.author}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: "16px", padding: "12px", background: T_GREEN_LIGHT, borderRadius: "8px", border: `1px solid #b6dfc4` }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: T_GREEN, marginBottom: "4px" }}>Thalia Club</div>
        <div style={{ fontSize: "11px", color: T_TEXT_MUTED, lineHeight: 1.5 }}>
          Du sammelst aktuell <strong style={{ color: T_GREEN }}>1.240 Punkte</strong> — noch 260 bis zur nächsten Prämie!
        </div>
      </div>
    </div>
  );
}

// ─── Main App ──────────────────────────────────────────────────────────────

export default function ThaliaReadingMentor() {
  const [phase, setPhase] = useState("idle");
  const [thinkStep, setThinkStep] = useState(-1);
  const [messages, setMessages] = useState([]);
  const [visibleBooks, setVisibleBooks] = useState([]);
  const [cart, setCart] = useState([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showToast, setShowToast] = useState(null);
  const [searchVal, setSearchVal] = useState("");
  const chatRef = useRef(null);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, isTyping, visibleBooks, thinkStep]);

  const addMsg = (text, isUser = false, delay = 0) =>
    new Promise(res => setTimeout(() => { setMessages(m => [...m, { text, isUser }]); res(); }, delay));

  const startAgent = async () => {
    setPhase("starting"); setMessages([]); setVisibleBooks([]); setThinkStep(-1);
    setIsTyping(true);
    await addMsg("Hallo! Ich bin dein persönlicher Lesementor. Ich analysiere gerade dein Leseprofil, um dir die passendsten Bücher zu empfehlen …", false, 900);
    setIsTyping(false);
    await new Promise(r => setTimeout(r, 500));
    setIsTyping(true);
    await addMsg("Du hast in den letzten 12 Monaten 14 Bücher bewertet. Deine Leidenschaft gilt literarischer Fiktion und philosophischen Werken — ein wunderbarer Geschmack! 📖", false, 1900);
    setIsTyping(false);
    setPhase("thinking");
    await new Promise(r => setTimeout(r, 600));
    for (let i = 0; i < thinkingSteps.length; i++) {
      setThinkStep(i);
      await new Promise(r => setTimeout(r, 850));
    }
    setIsTyping(true);
    await new Promise(r => setTimeout(r, 1000));
    await addMsg("Ich habe 4 Bücher gefunden, die außergewöhnlich gut zu dir passen. Jede Empfehlung ist individuell auf deine Lesehistorie abgestimmt:", false, 300);
    setIsTyping(false);
    setPhase("done");
    for (let i = 0; i < books.length; i++) {
      await new Promise(r => setTimeout(r, 380));
      setVisibleBooks(v => [...v, books[i].id]);
    }
  };

  const handleSend = async () => {
    if (!input.trim()) return;
    const text = input.trim();
    setInput("");
    setMessages(m => [...m, { text, isUser: true }]);
    setIsTyping(true);
    await new Promise(r => setTimeout(r, 1300));
    setIsTyping(false);
    let resp = "Das ist eine tolle Frage! Schau gerne auch in unserem kuratierten Regal für zeitgenössische Literatur vorbei. Kann ich dir noch etwas empfehlen?";
    if (text.toLowerCase().includes("krimi") || text.toLowerCase().includes("thriller"))
      resp = "Für Krimis wäre 'All the Colours of the Dark' von Chris Whitaker perfekt — literarisch und spannend zugleich!";
    else if (text.toLowerCase().includes("mehr") || text.toLowerCase().includes("weitere"))
      resp = "Noch mehr Entdeckungen: 'Wann hört es auf, weh zu tun' von Nino Haratischwili wäre der nächste logische Schritt für dich!";
    setMessages(m => [...m, { text: resp, isUser: false }]);
  };

  const handleAdd = (book) => {
    setCart(c => [...c, book]);
    setShowToast(book.title);
    setTimeout(() => setShowToast(null), 3000);
  };

  return (
    <div style={{ fontFamily: "'Source Sans 3', 'Helvetica Neue', Helvetica, Arial, sans-serif", background: T_BG, minHeight: "100vh" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes tDot  { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-5px)} }
        @keyframes tSpin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes tFade { from{opacity:0;transform:translateY(7px)} to{opacity:1;transform:translateY(0)} }
        @keyframes tSlide { from{opacity:0;transform:translateY(-10px)} to{opacity:1;transform:translateY(0)} }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #ccc; border-radius: 2px; }
        .nav-link:hover { color: #1e7a3c !important; }
        .icon-btn:hover { background: #f5f5f5; border-radius: 8px; }
        .search-bar:focus-within { box-shadow: 0 0 0 2px ${T_GREEN}; }
      `}</style>

      {/* ═══════════════════════════════════════════════
          HEADER — Weißer Hintergrund, Thalia-Logo, Suche, Icons
      ═══════════════════════════════════════════════ */}
      <header style={{
        background: T_WHITE,
        borderBottom: `1px solid ${T_BORDER}`,
        position: "sticky", top: 0, zIndex: 200,
      }}>
        {/* Top row */}
        <div style={{
          maxWidth: "1280px", margin: "0 auto",
          padding: "12px 24px",
          display: "flex", alignItems: "center", gap: "24px",
        }}>
          {/* Logo */}
          <div style={{ flexShrink: 0 }}>
            <ThaliaLogo />
          </div>

          {/* Search bar */}
          <div className="search-bar" style={{
            flex: 1, display: "flex", alignItems: "center",
            border: `1.5px solid ${T_BORDER}`, borderRadius: "28px",
            padding: "0 16px", height: "46px", background: T_WHITE,
            transition: "box-shadow 0.2s",
          }}>
            <input
              value={searchVal}
              onChange={e => setSearchVal(e.target.value)}
              placeholder="Titel, Autor, Stichwort, ISBN"
              style={{
                flex: 1, border: "none", outline: "none",
                fontSize: "14px", color: T_TEXT, fontFamily: "inherit",
                background: "transparent",
              }}
            />
            <button style={{
              background: T_GREEN, border: "none", borderRadius: "50%",
              width: "32px", height: "32px", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
              flexShrink: 0,
            }}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle cx="7" cy="7" r="5" stroke="white" strokeWidth="2"/>
                <path d="M11 11 L14.5 14.5" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          {/* Right icons */}
          <div style={{ display: "flex", alignItems: "center", gap: "4px", flexShrink: 0 }}>
            {/* Vor Ort */}
            <button className="icon-btn" style={{
              background: "none", border: "none", cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "center",
              padding: "6px 10px", gap: "2px",
            }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T_TEXT} strokeWidth="1.8" strokeLinecap="round">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
                <circle cx="12" cy="9" r="2.5"/>
              </svg>
              <span style={{ fontSize: "10px", color: T_TEXT, fontWeight: 600 }}>Vor Ort</span>
            </button>

            {/* Mein Konto */}
            <button className="icon-btn" onClick={() => setShowProfile(s => !s)} style={{
              background: "none", border: "none", cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "center",
              padding: "6px 10px", gap: "2px", position: "relative",
            }}>
              <div style={{ position: "relative" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T_TEXT} strokeWidth="1.8" strokeLinecap="round">
                  <circle cx="12" cy="8" r="4"/>
                  <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
                </svg>
                <div style={{
                  position: "absolute", top: -3, right: -3,
                  width: "10px", height: "10px", borderRadius: "50%",
                  background: T_ORANGE, border: "2px solid white",
                }} />
              </div>
              <span style={{ fontSize: "10px", color: T_TEXT, fontWeight: 600 }}>Mein Konto</span>
            </button>

            {/* Merkzettel */}
            <button className="icon-btn" style={{
              background: "none", border: "none", cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "center",
              padding: "6px 10px", gap: "2px", position: "relative",
            }}>
              <div style={{ position: "relative" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T_TEXT} strokeWidth="1.8" strokeLinecap="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <div style={{
                  position: "absolute", top: -5, right: -6,
                  minWidth: "16px", height: "16px", borderRadius: "8px",
                  background: T_GREEN, color: "white",
                  fontSize: "9px", fontWeight: 800,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  padding: "0 3px", border: "2px solid white",
                }}>0</div>
              </div>
              <span style={{ fontSize: "10px", color: T_TEXT, fontWeight: 600 }}>Merkzettel</span>
            </button>

            {/* Warenkorb */}
            <button className="icon-btn" style={{
              background: "none", border: "none", cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "center",
              padding: "6px 10px", gap: "2px", position: "relative",
            }}>
              <div style={{ position: "relative" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={T_TEXT} strokeWidth="1.8" strokeLinecap="round">
                  <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
                  <line x1="3" y1="6" x2="21" y2="6"/>
                  <path d="M16 10a4 4 0 0 1-8 0"/>
                </svg>
                <div style={{
                  position: "absolute", top: -5, right: -6,
                  minWidth: "16px", height: "16px", borderRadius: "8px",
                  background: T_GREEN, color: "white",
                  fontSize: "9px", fontWeight: 800,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  padding: "0 3px", border: "2px solid white",
                }}>{cart.length}</div>
              </div>
              <span style={{ fontSize: "10px", color: T_TEXT, fontWeight: 600 }}>Warenkorb</span>
            </button>
          </div>
        </div>

        {/* Category nav */}
        <nav style={{
          borderTop: `1px solid ${T_BORDER}`,
          background: T_WHITE,
        }}>
          <div style={{
            maxWidth: "1280px", margin: "0 auto", padding: "0 24px",
            display: "flex", alignItems: "center", gap: "0", overflowX: "auto",
          }}>
            {navItems.map((item, i) => (
              <a key={item} className="nav-link" style={{
                fontSize: "13px", fontWeight: item === "Lesementor" ? 700 : 600,
                color: item === "SALE" ? T_ORANGE : item === "Lesementor" ? T_GREEN : T_TEXT,
                padding: "12px 14px",
                textDecoration: "none",
                whiteSpace: "nowrap",
                borderBottom: item === "Lesementor" ? `3px solid ${T_GREEN}` : "3px solid transparent",
                cursor: "pointer",
                transition: "color 0.15s",
              }}>
                {item}
              </a>
            ))}
            {/* Active: Lesementor */}
            <a className="nav-link" style={{
              fontSize: "13px", fontWeight: 700, color: T_GREEN,
              padding: "12px 14px", textDecoration: "none", whiteSpace: "nowrap",
              borderBottom: `3px solid ${T_GREEN}`, cursor: "pointer",
            }}>
              ✦ Lesementor
            </a>
          </div>
        </nav>
      </header>

      {/* ─── Toast ─── */}
      {showToast && (
        <div style={{
          position: "fixed", top: "140px", right: "32px", zIndex: 999,
          background: T_WHITE, border: `1px solid ${T_BORDER}`,
          padding: "14px 18px", borderRadius: "8px",
          boxShadow: "0 4px 20px rgba(0,0,0,0.14)",
          animation: "tSlide 0.3s ease", borderTop: `3px solid ${T_GREEN}`,
          maxWidth: "280px",
        }}>
          <div style={{ fontSize: "13px", fontWeight: 700, color: T_TEXT, marginBottom: "2px" }}>✓ In den Warenkorb gelegt</div>
          <div style={{ fontSize: "12px", color: T_TEXT_MUTED }}>{showToast}</div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════
          HERO — Dunkles Teal, Kursivschrift + Buchcover
      ═══════════════════════════════════════════════ */}
      <div style={{
        background: T_HERO_BG,
        minHeight: "320px",
        display: "flex", alignItems: "center",
        position: "relative", overflow: "hidden",
      }}>
        <div style={{
          maxWidth: "1280px", margin: "0 auto", padding: "40px 24px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          width: "100%", gap: "40px",
        }}>
          {/* Left: text */}
          <div style={{ flex: "0 0 420px" }}>
            <div style={{
              display: "inline-flex", alignItems: "center", gap: "8px",
              background: "rgba(255,255,255,0.1)", borderRadius: "4px",
              padding: "5px 12px", marginBottom: "16px",
            }}>
              <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#4ade80", animation: "tDot 2s infinite" }} />
              <span style={{ fontSize: "11px", fontWeight: 700, color: "rgba(255,255,255,0.9)", letterSpacing: "0.1em" }}>
                KI-GESTÜTZTER LESEMENTOR · BETA
              </span>
            </div>

            <h1 style={{
              color: T_WHITE, lineHeight: 1.15, marginBottom: "16px",
            }}>
              <span style={{
                fontStyle: "italic",
                fontSize: "42px", fontWeight: 300,
                fontFamily: "Georgia, 'Times New Roman', serif",
                display: "block",
              }}>Dein persönlicher</span>
              <span style={{
                fontSize: "46px", fontWeight: 800,
                fontFamily: "'Source Sans 3', Helvetica, sans-serif",
                display: "block",
              }}>Lesementor</span>
            </h1>

            <p style={{
              color: "rgba(255,255,255,0.7)", fontSize: "15px",
              lineHeight: 1.65, marginBottom: "28px", maxWidth: "380px",
            }}>
              Unser KI-Agent analysiert dein Leseverhalten und findet Bücher, die wirklich zu dir passen.
            </p>

            {phase === "idle" ? (
              <button onClick={startAgent} style={{
                background: T_WHITE, color: T_GREEN,
                border: `2px solid ${T_WHITE}`, borderRadius: "28px",
                fontSize: "15px", fontWeight: 700, padding: "13px 28px",
                cursor: "pointer", transition: "all 0.2s",
              }}>
                Empfehlungen starten →
              </button>
            ) : (
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{
                  width: "9px", height: "9px", borderRadius: "50%",
                  background: phase === "done" ? "#4ade80" : T_ORANGE,
                  animation: phase !== "done" ? "tDot 1.2s infinite" : "none",
                }} />
                <span style={{ color: "rgba(255,255,255,0.85)", fontSize: "14px", fontWeight: 600 }}>
                  {phase === "done" ? "Analyse abgeschlossen · 4 Empfehlungen für dich" : "Lesementor ist aktiv …"}
                </span>
              </div>
            )}
          </div>

          {/* Right: decorative book grid */}
          <div style={{
            flex: 1, display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gridTemplateRows: "repeat(3, auto)",
            gap: "8px", opacity: 0.85,
          }}>
            {[
              ["#1a3a5c","#2e6da4"], ["#2c1810","#6a3a1a"], ["#3a1a5c","#7a3a9a"], ["#1a4a2e","#2e7a4a"],
              ["#4a1a1a","#8a3a3a"], ["#1a3a3a","#2e6a6a"], ["#3a3a1a","#7a7a2e"], ["#1a1a4a","#2e2e8a"],
              ["#4a2a1a","#8a5a3a"], ["#1a4a4a","#2e8a8a"], ["#2a1a4a","#5a3a8a"], ["#4a4a1a","#8a8a3a"],
            ].map((colors, i) => (
              <div key={i} style={{
                height: i % 3 === 1 ? "90px" : "70px",
                background: `linear-gradient(160deg, ${colors[0]}, ${colors[1]})`,
                borderRadius: "3px",
                boxShadow: "2px 2px 8px rgba(0,0,0,0.3)",
                transform: i % 4 === 2 ? "translateY(-6px)" : "none",
              }} />
            ))}
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════
          MAIN CONTENT
      ═══════════════════════════════════════════════ */}
      <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "28px 24px", display: "flex", gap: "24px" }}>

        {/* Sidebar */}
        {showProfile && (
          <div style={{
            width: "268px", flexShrink: 0, background: T_WHITE,
            borderRadius: "8px", border: `1px solid ${T_BORDER}`,
            padding: "22px", boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
            height: "fit-content", animation: "tFade 0.3s ease",
          }}>
            <ReadingProfile />
          </div>
        )}

        {/* Content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {phase !== "idle" && (
            <div style={{ display: "flex", gap: "20px" }}>

              {/* Chat Panel */}
              <div style={{
                width: "340px", flexShrink: 0, background: T_WHITE,
                border: `1px solid ${T_BORDER}`, borderRadius: "8px",
                display: "flex", flexDirection: "column", height: "620px",
                boxShadow: "0 1px 6px rgba(0,0,0,0.06)",
              }}>
                <div style={{
                  padding: "14px 16px", borderBottom: `1px solid ${T_BORDER}`,
                  display: "flex", alignItems: "center", gap: "10px",
                  background: T_GREEN_LIGHT, borderRadius: "8px 8px 0 0",
                }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: T_GREEN, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px" }}>📚</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "14px", color: T_GREEN }}>Lesementor</div>
                    <div style={{ display: "flex", alignItems: "center", gap: "5px", fontSize: "11px", color: "#16a34a", fontWeight: 600 }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#16a34a" }} />
                      KI-Agent · Online
                    </div>
                  </div>
                </div>

                <div ref={chatRef} style={{ flex: 1, overflowY: "auto", padding: "14px 14px 6px" }}>
                  {messages.map((m, i) => <ChatBubble key={i} msg={m.text} isUser={m.isUser} />)}
                  {isTyping && (
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: T_GREEN, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px" }}>📚</div>
                      <TypingDots />
                    </div>
                  )}
                  {phase === "thinking" && thinkStep >= 0 && <AgentThinking currentStep={thinkStep} />}
                </div>

                <div style={{ padding: "12px 14px", borderTop: `1px solid ${T_BORDER}` }}>
                  <div style={{ display: "flex", gap: "7px" }}>
                    <input
                      value={input}
                      onChange={e => setInput(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && handleSend()}
                      placeholder="Frag den Lesementor …"
                      style={{
                        flex: 1, border: `1.5px solid ${T_BORDER}`, borderRadius: "22px",
                        padding: "9px 14px", fontSize: "13px", outline: "none",
                        fontFamily: "inherit", color: T_TEXT,
                      }}
                      onFocus={e => e.target.style.borderColor = T_GREEN}
                      onBlur={e => e.target.style.borderColor = T_BORDER}
                    />
                    <button onClick={handleSend} style={{
                      background: T_GREEN, color: "white", border: "none",
                      borderRadius: "50%", width: "38px", height: "38px",
                      cursor: "pointer", fontSize: "15px", flexShrink: 0,
                    }}>↑</button>
                  </div>
                  <div style={{ display: "flex", gap: "5px", marginTop: "8px", flexWrap: "wrap" }}>
                    {["Mehr Bücher", "Krimis & Thriller", "Bestseller"].map(s => (
                      <button key={s} onClick={() => setInput(s)} style={{
                        background: "transparent", border: `1px solid ${T_BORDER}`, color: T_TEXT_MUTED,
                        fontSize: "11px", padding: "4px 10px", borderRadius: "14px",
                        cursor: "pointer", fontFamily: "inherit",
                      }}>{s}</button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Book Recommendations */}
              <div style={{ flex: 1, minWidth: 0, overflowY: "auto", maxHeight: "620px" }}>
                {phase === "done" && (
                  <div style={{ marginBottom: "14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div>
                      <h2 style={{ fontSize: "19px", fontWeight: 800, color: T_TEXT }}>Deine persönlichen Empfehlungen</h2>
                      <div style={{ fontSize: "12px", color: T_TEXT_MUTED, marginTop: "2px" }}>
                        Basierend auf 14 bewerteten Büchern · Aktualisiert heute
                      </div>
                    </div>
                    <button style={{
                      background: T_WHITE, border: `1.5px solid ${T_BORDER}`, color: T_TEXT_MUTED,
                      fontSize: "12px", padding: "7px 14px", borderRadius: "22px",
                      cursor: "pointer", fontFamily: "inherit", fontWeight: 600,
                    }}>↻ Neu generieren</button>
                  </div>
                )}
                {books.map(book => (
                  <BookCard key={book.id} book={book} visible={visibleBooks.includes(book.id)} onAdd={handleAdd} />
                ))}
              </div>
            </div>
          )}

          {phase === "idle" && (
            <div style={{ textAlign: "center", padding: "60px 20px", color: T_TEXT_MUTED }}>
              <div style={{ fontSize: "48px", marginBottom: "16px" }}>📚</div>
              <div style={{ fontSize: "18px", fontWeight: 700, color: T_TEXT, marginBottom: "8px" }}>
                Bereit für deine nächsten Lieblingsbücher?
              </div>
              <div style={{ fontSize: "14px", marginBottom: "24px" }}>
                Klicke oben auf „Empfehlungen starten" um den Lesementor zu aktivieren.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer style={{
        background: T_HERO_BG, color: "rgba(255,255,255,0.55)",
        padding: "24px 32px", marginTop: "40px", fontSize: "12px",
      }}>
        <div style={{ maxWidth: "1280px", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <svg width="22" height="22" viewBox="0 0 38 38" fill="none">
              <path d="M19 4 C14 4 8 8 7 14 C6 18 8 21 11 23 C9 25 8 28 9 31 C11 28 14 26 17 25 C18 26 19 27 19 29 C19 27 20 25 22 24 C25 25 27 28 29 31 C30 28 29 25 27 23 C30 21 32 18 31 14 C30 8 24 4 19 4Z" fill="white" opacity="0.7"/>
            </svg>
            <span style={{ fontWeight: 800, color: T_WHITE, fontSize: "16px" }}>Thalia</span>
          </div>
          <div>© 2025 Thalia Bücher GmbH · Hagen · <em>Welt, bleib wach.</em></div>
          <div style={{ display: "flex", gap: "16px" }}>
            {["Datenschutz", "Impressum", "AGB"].map(l => (
              <span key={l} style={{ cursor: "pointer" }}>{l}</span>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
